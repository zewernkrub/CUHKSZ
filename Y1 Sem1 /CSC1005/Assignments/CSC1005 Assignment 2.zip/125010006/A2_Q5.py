def character_frequency(str):
    freq=dict()
    for char in str:
        freq[char]=freq.get(char,0)+1
    newlst=dict()
    for char,count in freq.items():
        if count not in newlst:
            newlst[count]=[]
        newlst[count].append(char)
    for count in newlst:
            newlst[count].sort()
    tmp=list()
    for e in newlst.items():
        tmp.append(e)
    tmp.sort()
    final=dict(tmp)
    return final