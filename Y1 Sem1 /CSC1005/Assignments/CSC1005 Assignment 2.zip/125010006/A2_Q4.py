def group_rotated_words(lst):
    rotate=dict()
    used=set()
    for word in lst:
        doubled=word*2
        rotations = [doubled[i:i + len(word)] for i in range(len(word))]
        key=min(rotations)
        rotate[key]=rotations
        rotate[key].sort()
    return list(rotate.values())