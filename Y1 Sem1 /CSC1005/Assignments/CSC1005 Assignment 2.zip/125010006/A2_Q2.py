def checkMirror(str):
    newstr=""
    i=0
    while i<len(str):
        newstr+=str[len(str)-i-1]
        i+=1
    if(newstr==str):
        return True
    else:
        return False
def find_mirror_words(str):
    wordlst=str.split()
    newWordlst=[]
    for word in wordlst:
        if checkMirror(word):
            newWordlst.append(word)
    return newWordlst