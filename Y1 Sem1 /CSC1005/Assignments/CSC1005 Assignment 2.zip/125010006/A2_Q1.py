def checkPrime(num):
    if num == 1:
        return False
    if num == 2 or num == 3:
        return True
    if (num % 2 == 0 or num % 3 == 0):
        return False
    i = 2
    while i * i <= num:
        if (num % i == 0):
            return False
        i += 1
    return True
def main():
    N = int(input())
    num = 1
    count = 0
    RPS = []
    while count <= N:
        sqNum = num * num  # take sqrt of the number
        sqNum = str(sqNum)  # turn to string to reverse
        digit = len(sqNum)  # give number of digits
        newNum = ""  # empty str of new number
        i = 0
        while i < digit:
            newNum += str(sqNum[digit - 1 - i])  # take digits from the old number reversely
            i += 1
        newNum = int(newNum)

        sqNum = int(sqNum)
        if checkPrime(newNum) == True:
            RPS.append(sqNum)
            count += 1
        num += 1
    j = 1
    while j <= N:
        if j % 10 != 0:
            print("%d" % RPS[j - 1], end=" ")
            j += 1
        else:
            print("%d" % RPS[j - 1])
            j += 1
main()