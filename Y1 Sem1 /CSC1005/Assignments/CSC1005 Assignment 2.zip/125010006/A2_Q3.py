def group_anagrams(lst):
    anagrams=dict()
    for word in lst:
        key=''.join(sorted(word))
        if key in anagrams:
            anagrams[key].append(word)
        else:
            anagrams[key] = [word]
    return list(anagrams.values())
