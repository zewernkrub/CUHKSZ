def HanoiTower(n):
    if n <= 0 or type(n)!=int:
        return "Value Error: n has to be positive integer"
    # Stack will hold tuples: (n, source, target, auxiliary)
    stack = []
    # Start by pushing the initial problem
    stack.append((n, 'A', 'C', 'B'))
    while stack:
        n, first, last, mid = stack.pop()
        if n == 1:
            # Base case: just print the move
            print(f"{first}->{last}")
        else:
            # Simulate the recursive calls in reverse order
            # Because stack is LIFO, we push in reverse order of execution
            # Third recursive call: move(n-1, auxiliary, target, source)
            stack.append((n - 1, mid, last, first))
            # Second: move largest disc
            stack.append((1, first, last, mid))

            # First recursive call: move(n-1, source, auxiliary, target)
            stack.append((n - 1, first, mid, last))