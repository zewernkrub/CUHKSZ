def economic_dispatch():
    # Define the total cost function
    def total_cost(P):
        P1, P2, P3 = P
        C1 = 0.02 * P1 ** 2 + 10 * P1 + 100
        C2 = 0.03 * P2 ** 2 + 8 * P2 + 120
        C3 = 0.025 * P3 ** 2 + 9 * P3 + 150
        return C1 + C2 + C3
    # Define the equality constraint (power balance)
    def power_balance(P):
        return np.sum(P) - 300  # P1 + P2 + P3 - P_load

    # Define constraints and bounds
    constraints = {'type': 'eq', 'fun': power_balance}

    # Bounds for each generator: (min, max)
    bounds = [(50, 150),  # Generator 1: 50 <= P1 <= 150
              (50, 100),  # Generator 2: 50 <= P2 <= 100
              (50, 120)]  # Generator 3: 50 <= P3 <= 120
    # Initial guess (feasible point that satisfies constraints)
    P0 = np.array([100.0, 80.0, 120.0])
    # Solve the optimization problem
    result = minimize(total_cost, P0, method='SLSQP', bounds=bounds, constraints=constraints)
    # Extract optimal values
    P1_opt, P2_opt, P3_opt = result.x
    total_cost_opt = result.fun
    # Round to integers as requested
    P1_rounded = round(P1_opt)
    P2_rounded = round(P2_opt)
    P3_rounded = round(P3_opt)
    total_cost_rounded = round(total_cost_opt)
    return P1_rounded, P2_rounded, P3_rounded, total_cost_rounded
# Solve and print the results

P1, P2, P3, total_cost = economic_dispatch()
print("Optimal Power Outputs:")
print("P1: <%d in MW>"%P1)
print("P2: <%d in MW>"%P2)
print("P3: <%d in MW>"%P3)
print("")
print("Total Generation Cost: <$%d>"%total_cost)