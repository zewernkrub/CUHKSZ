def dfs_traversal(tree, order):
    #Performs DFS traversal on a binary tree represented as a list.
    if not tree or tree[0] is None or type(tree)!=list:
        raise TypeError ("Please provide a valid binary tree.")
    resultLst = []

    def traverse(index):
        # Base case: index out of bounds or node is None
        if index >= len(tree) or tree[index] is None:
            return
        if order == "preorder":
            resultLst.append(tree[index])
            traverse(2 * index + 1)  # left
            traverse(2 * index + 2)  # right
        elif order == "inorder":
            traverse(2 * index + 1)  # left
            resultLst.append(tree[index])
            traverse(2 * index + 2)  # right
        elif order == "postorder":
            traverse(2 * index + 1)  # left
            traverse(2 * index + 2)  # right
            resultLst.append(tree[index])
        else:
            raise ValueError("Order must be 'preorder', 'inorder', or 'postorder'.")

    traverse(0)
    return resultLst