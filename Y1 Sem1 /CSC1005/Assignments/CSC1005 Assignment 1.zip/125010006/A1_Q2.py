def checkPrime(num):
    if num ==1:
        return False
    if num==2 or num==3:
        return True
    i=2
    while i<=num//2:
        if(num%i==0):
            return False
        i+=1
    return True
def main():
    n=int(input())
    if checkPrime(n):
        print("%d is a prime number."%n)
    else:
        print("%d is not a prime number."%n)
main()