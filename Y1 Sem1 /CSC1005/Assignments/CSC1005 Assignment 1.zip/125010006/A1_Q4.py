def factorial(n):
    if n==0:
        return 1
    prod=1
    for i in range(1,n+1):
        prod = prod*i
    return prod
try:
    num = int(input())
    if(num<0):
        print("Illegal input!")
    else:
        print("The factorial of %d is: %d" %(num, factorial(num)))
except:
    print("Illegal input!")