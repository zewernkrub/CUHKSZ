def isPrime(num):
    if(num<2):
        return False
    if num in (2,3):
        return True
    for i in range(2,num):
        if(num%i==0):
            return False
    return True
user_input=input().strip()
try:
    N=int(user_input)
except:
    print("Illegal input!")
    exit()
if(N<=0):
    print("Illegal input!")
else:
    print("The perfect numbers smaller than %d are:"%N)
    p=2
    while (2**(p-1))*(2**p-1)<=N:
        mersenne=2**p-1
        if isPrime(mersenne):
            perfNum=(2**(p-1)) * mersenne
            if(perfNum<N):
                print(perfNum)
        p+=1
