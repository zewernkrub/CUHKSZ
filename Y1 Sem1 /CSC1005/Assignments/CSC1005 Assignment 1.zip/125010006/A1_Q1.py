#Question 1
num=int(input()) #let user input the number
for i in range(num): #print first n even numbers
    print(2*i)
