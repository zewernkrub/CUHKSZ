numTuple=tuple(int(x) for x in input().split())
def checkMax(tuple):
    maxNum = None
    for i in tuple:
        if maxNum==None or maxNum<i:
            maxNum=i
    return maxNum
print("The largest number is: %d"%checkMax(numTuple))
