class Book:
    def __init__(self,ISBN,title,author):
        self.ISBN=ISBN
        self.title=title
        self.author=author
        self.is_available=True
    def get_isbn(self):
        return self.ISBN
    def get_title(self):
        return self.title
    def get_author(self):
        return self.author
    def get_available(self):
        return self.is_available
    def check_out(self):
        if self.is_available:
            self.is_available=False
            return True
        return False
    def return_book(self):
        if not self.is_available:
            self.is_available=True
            return True
        return False
    def __str__(self):
        return f"ISBN: {self.ISBN}, Title: {self.title},Author: {self.author}, Available: {True if self.is_available else False}"
    def __repr__(self):
        return self.__str__()
class Member:
    def __init__(self,member_id,name):
        self.member_id=member_id
        self.name=name
        self.borrowed_books=[]
    def get_member_id(self):
        return self.member_id
    def get_name(self):
        return self.name
    def get_borrowed_books(self):
        return self.borrowed_books
    def borrow_book(self,book):
        if len(self.borrowed_books)>=3:
            return False, "Your borrowed books exceed limit."
        if book in self.borrowed_books:
            return False, "Book already borrowed by this member."
        self.borrowed_books.append(book)
        return True, "Book borrowed successfully."
    def return_book(self, book):
        if book in self.borrowed_books:
            self.borrowed_books.remove(book)
            return True, "Book returned successfully."
        return False,"Book not found in borrowed list"
    def __str__(self):
        return f"{self.member_id}: {self.name}, Borrowed books: {self.borrowed_books}"
    def __repr__(self):
        return self.__str__()
class Library:
    def __init__(self):
        self.books=[]
        self.members=[]
    def add_book(self,book):
        if not isinstance(book,Book):
            return False,"invalid book object"
        for existing_book in self.books:
            if existing_book==book:
                return False,f"Book with ISBN {book.get_isbn()} already added."
        self.books.append(book)
        return True,"book added successfully."
    def add_member(self,member):
        if not isinstance(member,Member):
            return False,"invalid member object"
        for existing_member in self.members:
            if existing_member==member:
                return False,f"Member with memberId {member.get_member_id()} already added."
        self.members.append(member)
        return True,"member added successfully."
    def check_out_book(self,isbn,member_id):
        book=None
        for b in self.books:
            if b.get_isbn()==isbn:
                book=b
                break
        if book is None:
            return False,f"Book with ISBN {isbn} not found."
        member=None
        for m in self.members:
            if m.get_member_id()==member_id:
                member=m
                break
        if member is None:
            return False,f"Member with member ID {member_id} not found."
        if not book.get_available():
            return False,"Book is already checked out"
        success,message=member.borrow_book(book)
        if not success:
            return False,message
        book.check_out()
        return True,f"{member.get_name()} successfully checked out the book."
    def return_book(self,isbn,member_id):
        book = None
        for b in self.books:
            if b.get_isbn() == isbn:
                book = b
                break
        if book is None:
            return False, f"Book with ISBN {isbn} not found."
        member = None
        for m in self.members:
            if m.get_member_id() == member_id:
                member = m
                break
        if member is None:
            return False,f"Member with member ID {member_id} not found."
        if book.get_available():
            return False,"Book is already returned."
        success,message=member.return_book(book)
        if not success:
            return False,message
        book.return_book()
        return True,f"{member.get_name()} successfully returned the book."
    def get_available_books(self):
        return [book for book in self.books if book.get_available()]
    def get_members_books(self,member_id):
        member = None
        for m in self.members:
            if m.get_member_id() == member_id:
                member = m
                break
        if member is None:
            return False, f"Member with member ID {member_id} not found."
        return member.get_borrowed_books()
    def get_members(self):
        return self.members
    def __str__(self):
        return f"Books:{self.books}, Members:{self.members}"
    def __repr__(self):
        return self.__str__()

def main():
    library=Library()
    book1=Book("123-456","Python Programming","John Smith")
    book2=Book("789-012","Data Structures", "Jane Doe")
    library.add_book(book1)
    library.add_book(book2)
    member=Member("M001","Alice Brown")
    library.add_member(member)
    library.check_out_book("123-456","M001")
    for b in library.get_available_books():
        print(b)
    print(library.get_members_books("M001"))
main()

