class ComplexNumber:
    def __init__(self,value):
        self.real=0.0
        self.imag=0.0
        if isinstance(value,ComplexNumber):
            self.real=value.real
            self.imag=value.imag
            return
        if isinstance(value,int) or isinstance(value,float):
            self.real=value
            self.imag=0.0
            return
        if isinstance(value,str):
            self.real, self.imag = self._parse(value)
            return
        raise TypeError("Invalid input type: the input must be a complex string or complex number.")
    def _parse(self,s):
        s=s.replace(' ','')
        if s=='+i'or s=='i':
            return 0.0,1.0
        if s=='-i':
            return 0.0,-1.0
        if '+' not in s and '-' not in s and 'i' in s:
            return 0.0, float(s[:-1])
        if 'i' not in s:
            return float(s),0.0
        s=s[:-1]
        for i in range(1,len(s)):
            if s[i]=='+' or s[i]=='-':
                real=s[:i]
                imag=s[i:]
                real=float(real)
                if imag=='+':
                    imag=1.0
                elif imag=='-':
                    imag=-1.0
                else:
                    imag=float(imag)
                return real,imag
        raise ValueError("Invalid format")
    def __add__(self,other):
        if not isinstance(other,ComplexNumber):
            raise ValueError("Invalid format: must be complex number")
        return ComplexNumber(f"{self.real+other.real}{'+' if self.imag+other.imag>=0 else ''}{self.imag+other.imag}i")
    def __sub__(self,other):
        if not isinstance(other,ComplexNumber):
            raise ValueError("Invalid format: must be complex number")
        return ComplexNumber(f"{self.real - other.real}{'+' if self.imag - other.imag >= 0 else ''}{self.imag - other.imag}i")
        return result
    def __mul__(self,other):
        if not isinstance(other,ComplexNumber):
            raise ValueError("Invalid format: must be complex number")
        R=self.real*other.real-self.imag*other.imag
        I=self.imag*other.real + other.imag*self.real
        sign='+' if I >= 0 else ''
        return ComplexNumber(f"{R}{sign}{I}i")
    def __truediv__(self,other):
        if not isinstance(other,ComplexNumber):
            raise ValueError("Invalid format: must be complex number")
        D = other.real * other.real + other.imag * other.imag
        R=(other.real*self.real+self.imag*other.imag)/D
        I=(other.real*self.imag-self.real*other.imag)/D
        if D==0:
            raise ZeroDivisionError("Division by zero")
        sign='+' if I >= 0 else ''
        trueR=(f"{R:.2f}")
        trueI=(f"{I:.2f}")
        return ComplexNumber(f"{trueR}{sign}{trueI}i")
    def __repr__(self):
        return self.output()
    def output(self):
        is_real_int=self.real==int(self.real)
        is_imag_int=self.imag==int(self.imag)
        if self.real==0:
            real_str=''
        elif is_real_int:
            real_str=str(int(self.real))
        else:
            real_str=str(float(self.real))
        sign=''
        if self.real!=0 and self.imag>=0:
            sign='+'
        if self.imag==0:
            return real_str
        elif self.imag==1:
            imag_str=''
        elif self.imag==-1:
            imag_str='-'
        elif is_imag_int:
            imag_str=str(int(self.imag))
        else:
            imag_str=str(float(self.imag))
        if self.real==0:
            if self.imag==1:
                return 'i'
            elif self.imag==-1:
                return '-i'
            else:
                return f"{imag_str}i"
        if self.imag==1:
            return f"{real_str}+i"
        elif self.imag==-1:
            return f"{real_str}-i"
        return f"{real_str}{sign}{imag_str}i"
    def __str__(self):
        return self.output()
def main():
    num1=ComplexNumber("9")
    num2=ComplexNumber("8-i")
    print(num1+num2)
    print(num1-num2)
    print(num1*num2)
    print(num1/num2)
main()