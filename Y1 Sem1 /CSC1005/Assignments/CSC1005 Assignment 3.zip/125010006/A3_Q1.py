class Matrix:
    def __init__(self, matrix):
        if not isinstance(matrix,list) or len(matrix)!=2 or any (not isinstance(row,list) or len(row)!=2 for row in matrix):
            raise TypeError('Matrix must be a 2x2 list of lists')
        self.matrix=matrix
    def __add__(self,other):
        if not isinstance(other,Matrix):
            raise TypeError("Matrix must be of type Matrix")
        newMatrix=[[],[]]
        for i in range(2):
            for j in range(2):
                newMatrix[i].append(self.matrix[i][j]+other.matrix[i][j])
        return Matrix(newMatrix)
    def __sub__(self,other):
        if not isinstance(other,Matrix):
            raise TypeError("Matrix must be of type Matrix")
        newMatrix=[[],[]]
        for i in range(2):
            for j in range(2):
                newMatrix[i].append(self.matrix[i][j]-other.matrix[i][j])
        return Matrix(newMatrix)
    def __mul__(self,other):
        if not isinstance(other,Matrix):
            raise TypeError("Matrix must be of type Matrix")
        newMatrix=[[0,0],[0,0]]
        for i in range(2):
            for j in range(2):
                for k in range(2):
                    newMatrix[i][j]+=self.matrix[i][k]*other.matrix[k][j]
        return Matrix(newMatrix)
    def __repr__(self):
        return f"{self.matrix}"
def main():
    matrix1=Matrix([[1,2],[3,4]])
    matrix2=Matrix([[5,6],[7,8]])
    print(matrix1+matrix2)
    print(matrix1-matrix2)
    print(matrix1*matrix2)
main()